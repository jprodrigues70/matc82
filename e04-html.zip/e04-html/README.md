#Exercício 04 - HTML

    1. Criar a página menu.html, cadastroCliente.html, cadastroFuncionario.html
    2. Na página menu.html:
      - adicione um background com uma imagem;
      - adicione imagens .jpg em formato de botão apontando para as páginas de Cadastro de Cliente e para cadastro de Funcionário.
    3. Na página cadastroCliente.html, crie um topo em imagem contendo o título da página "Cadastro de Cliente" e adicione os campos abaixo num formulário e um botão de voltar ao menu.
      - Nome
      - Telefone Celular
      - Endereço Completo
      - Data Nascimento
    4. Na página cadastroFuncionario.html, crie um topo em imagem contendo o título da página "Cadastro de Funcinoário" no mesmo padrão da página de cliente e adicione os campos abaixo num formulário e um botão de voltar ao menu.
      - Matrícula
      - Nome
      - Função
      - Data Nascimento
